<?php
require_once "includes/header.php";
require_once "includes/navbar.php";
require_once "sections/Home.php";
require_once "includes/footer.php";	
?>
