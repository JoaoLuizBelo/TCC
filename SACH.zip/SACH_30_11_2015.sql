CREATE DATABASE  IF NOT EXISTS `sach` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sach`;
-- MySQL dump 10.13  Distrib 5.6.23, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: sach
-- ------------------------------------------------------
-- Server version	5.6.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `calendario`
--

DROP TABLE IF EXISTS `calendario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ano` int(4) DEFAULT NULL,
  `mes` int(2) DEFAULT NULL,
  `dia` int(2) DEFAULT NULL,
  `diaSemana` int(1) DEFAULT NULL,
  `Ocorrencia_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Ocorrencia_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendario`
--

LOCK TABLES `calendario` WRITE;
/*!40000 ALTER TABLE `calendario` DISABLE KEYS */;
INSERT INTO `calendario` VALUES (1,2014,1,1,1,1),(2,2014,1,2,2,1),(3,2014,1,3,3,1),(4,2014,1,4,4,1),(5,2014,1,5,5,1),(6,2014,1,6,6,1),(7,2014,1,7,7,1),(8,2014,1,8,8,1),(9,2014,1,9,9,1),(10,2014,1,10,10,1),(11,2014,1,11,11,1),(12,2014,1,12,12,1),(13,2014,1,13,13,1),(14,2014,1,14,14,1),(15,2014,1,15,15,1),(16,2014,1,16,16,1),(17,2014,1,17,17,1),(18,2014,1,18,18,1),(19,2014,1,19,19,1),(20,2014,1,20,20,1),(21,2014,1,21,21,1),(22,2014,1,22,22,1),(23,2014,1,23,23,1),(24,2014,1,24,24,1),(25,2014,1,25,25,1),(26,2014,1,26,26,1),(27,2014,1,27,27,1),(28,2014,1,28,28,1),(29,2014,1,29,29,1),(30,2014,1,30,30,1),(31,2014,1,31,31,1);
/*!40000 ALTER TABLE `calendario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cargo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomCompleto` varchar(45) DEFAULT NULL,
  `nomAbrev` varchar(45) DEFAULT NULL,
  `codigo` int(11) DEFAULT NULL,
  `cancelado` tinyint(1) DEFAULT NULL,
  `cbo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (1,'ANALISTA DE SUPORTE','ANA. SUP.',1,0,0),(2,'AUXILIAR DE CRECHE','AUX DE CRECHE',2,0,0),(3,'ASSISTENTE DE RECURSOS HUMANOS','ASS. RH',3,0,0),(4,'PEDREIRO','PEDR.',4,0,0),(5,'INSPETOR DE ALUNOS','INSP.',5,0,0),(6,'AUXILIAR DE SERVIÇOS GERAIS','AUX. SERV. GER.',6,0,0),(7,'TÉCNICA ENFERMAGEM','TEC. ENF.',7,0,0),(8,'CARPINTEIRO','CARP.',8,0,0),(9,'INSTRUTOR DE MÚSICA','INST. MUS.',9,0,0),(10,'ASSISTENTE DE COMUNICAÇÃO','ASS. COM.',10,0,0),(11,'INSTRUTOR DE CAPOEIRA','INST. CAP.',11,0,0),(12,'ASCENSORISTA','ASC.',12,0,0),(13,'AUXILIAR DE TESOURARIA','AUX. TESOUR.',13,0,0),(14,'JARDINEIRO','JARD.',14,0,0),(15,'ASSISTENTE DE INFRAESTRUTURA','ASS. INFR.',15,0,0),(16,'INSTRUTOR DE ENSINO PROFISSIONALIZANTE','INST. ENS. PROF.',16,0,0),(17,'AUXILIAR DE SECRETÁRIA','AUX. SECRET.',16,0,0),(18,'OFICIAL SERRALHEIRO I','OFIC. SERR. I',17,0,0),(19,'TÉCNICO DE SUPORTE LABORATÓRIO DE INFÓRMATICA','TEC. SUP. LAB. INF.',18,0,0),(20,'BOMBEIRO HIDRÁULICO','BOMB. HIDRA.',19,0,0),(21,'AUXILIAR SECRETÁRIA SUPERINTENDENCIA','AUX. SECRET. SUPERIN.',20,0,0),(22,'AUXILIAR ADMINISTRAÇÃO','AUX. ADM.',21,0,0),(23,'SUPERVISOR DE ATENDIMENTO AO CLIENTE','SUP. ATEN. CLIEN.',22,0,0),(24,'1/2 OFICIAL PINTOR','1/2 OFIC. PINT.',23,0,0),(25,'INSPETOR SEGURANÇA','INSP. SEG.',24,0,0),(26,'OPERADOR MÁQUINA COPIADORA','OP. COP.',25,0,0),(27,'PORTEIRO','PORT.',26,0,0),(28,'AUXILIAR DE INFRAESTRUTURA','AUX. INFR.',27,0,0),(29,'1/2 OFICIAL ELETRICISTA','1/2 OFIC. ELETR.',28,0,0),(30,'AUXILIAR BIBLIOTECA','AUX. BIBLI.',29,0,0),(31,'AUXILIAR REFRIGERAÇÃO','AUX. REFR.',30,0,0),(32,'ANALISTA DE RECURSOS HUMANOS','ANA. REC. HUM.',31,0,0),(33,'ASSISTENTE DE RECURSOS HUMANOS II','ASS. REC. HUM. II',32,0,0),(34,'AGENTE ADMINISTRATIVO','AG. ADM.',33,0,0),(35,'AUXILIAR DE COZINHA','AUX. COZ.',34,0,0),(36,'AUXILIAR SUPORTE ADM/LAB INFORMATICA I','AUX. SUP. ADM. LAB. INF. I',35,0,0),(37,'TÉCNICO DE REFRIGERAÇÃO','TEC. REFR.',36,0,0),(38,'OFICIAL SERRALHEIRO','OFIC. SERR.',37,0,0),(39,'ATENDENTE CALL CENTER','ATEN. CALL CENT.',38,0,0),(40,'AUXILIAR DE ATENDIMENTO I','AUX. ATEND.I',39,0,0),(41,'AUXILIAR DE PATRIMÔNIO','AUX. PATR.',40,0,0),(42,'MOTORISTA','MOT',41,0,0),(43,'RECEPCIONISTA','RECP.',42,0,0),(44,'TÉCNICO DE PROGRAMAÇÃO INFO II','TÉCN. PROGR.',43,0,0),(45,'AUXILIAR DE COORDENAÇÃO DE TEATRO','AUX. COOR. TEATRO',44,0,0),(46,'TÉCNICO EM REDE DE COMPUTADORES II','TEC. REDE',45,0,0),(47,'ENCARREGADO COORDENAÇÃO E INSPETORIA','ENC. INSP.',46,0,0),(48,'ASSISTENTE ECONOMICA FINANCEIRA I','ASS. FIN.I',47,0,0),(49,'AUXILIAR DE PROGRAMAÇÃO','AUX. PROG.',48,0,0),(50,'SERVENTE','SERV.',49,0,0),(51,'TÉCNICO DE SUPORTE ADMINISTRATIVO DE INFO I','TEC. SUP. ADM.',50,0,0),(52,'TÉCNICO DE SUPORTE DE LABORÁTORIO INFORMÁTICA','TEC. SUP. INF. V',51,0,0),(53,'ENCARREGADO DE INSPETORIA','ENC. INSP.',52,0,0),(54,'RECREADORA','RECR.',53,0,0);
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartao`
--

DROP TABLE IF EXISTS `cartao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cartao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ano` int(4) DEFAULT NULL,
  `mes` int(2) DEFAULT NULL,
  `dia` int(2) DEFAULT NULL,
  `ent1` varchar(5) DEFAULT NULL,
  `ent2` varchar(5) DEFAULT NULL,
  `ent3` varchar(5) DEFAULT NULL,
  `sai1` varchar(5) DEFAULT NULL,
  `sai2` varchar(5) DEFAULT NULL,
  `sai3` varchar(5) DEFAULT NULL,
  `diaSemana` int(1) DEFAULT NULL,
  `Ocorrencia_id` int(11) NOT NULL,
  `TipoCartao_id` int(11) NOT NULL,
  `Colaborador_id` int(11) NOT NULL,
  `Justificativa_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`,`Ocorrencia_id`,`TipoCartao_id`,`Colaborador_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartao`
--

LOCK TABLES `cartao` WRITE;
/*!40000 ALTER TABLE `cartao` DISABLE KEYS */;
INSERT INTO `cartao` VALUES (1,2015,2,21,'FG','FG','FG','FG','FG','FG',7,5,11,2,0),(2,2015,2,22,'FG','FG','FG','FG','FG','FG',1,5,11,2,0),(3,2015,2,23,'10:26','14:00','00:00','13:00','17:48','00:00',2,1,11,2,0),(4,2015,2,24,'08:06','14:00','00:00','13:00','18:26','00:00',3,1,11,2,0),(5,2015,2,25,'08:14','14:00','00:00','13:00','17:54','00:00',4,1,11,2,0),(6,2015,2,26,'08:01','14:00','00:00','13:00','19:01','00:00',5,1,11,2,0),(7,2015,2,27,'08:00','14:00','00:00','13:00','17:50','00:00',6,1,11,2,0),(8,2015,2,28,'FG','FG','FG','FG','FG','FG',7,5,11,2,0),(9,2015,3,1,'FG','FG','FG','FG','FG','FG',1,5,11,2,0),(10,2015,3,2,'08:32','14:00','00:00','13:00','18:48','00:00',2,1,11,2,0),(11,2015,3,3,'09:08','14:00','00:00','13:00','18:02','00:00',3,1,11,2,0),(12,2015,3,4,'08:57','14:00','00:00','13:00','17:51','00:00',4,1,11,2,0),(13,2015,3,5,'09:00','14:00','00:00','13:00','18:48','00:00',5,1,11,2,0),(14,2015,3,6,'09:00','14:00','00:00','13:00','18:48','00:00',6,1,11,2,0),(15,2015,3,7,'FG','FG','FG','FG','FG','FG',7,5,11,2,0),(16,2015,3,8,'FG','FG','FG','FG','FG','FG',1,5,11,2,0),(17,2015,3,9,'09:00','14:00','00:00','13:00','18:48','00:00',2,1,11,2,0),(18,2015,3,10,'09:00','14:00','00:00','13:00','18:48','00:00',3,1,11,2,0),(19,2015,3,11,'09:00','14:00','00:00','13:00','18:48','00:00',4,1,11,2,0),(20,2015,3,12,'09:00','14:00','00:00','13:00','18:48','00:00',5,1,11,2,0),(21,2015,3,13,'09:00','14:00','00:00','13:00','18:48','00:00',6,1,11,2,0),(22,2015,3,14,'FG','FG','FG','FG','FG','FG',7,5,11,2,0),(23,2015,3,15,'FG','FG','FG','FG','FG','FG',1,5,11,2,0),(24,2015,3,16,'09:00','14:00','00:00','13:00','18:48','00:00',2,1,11,2,0),(25,2015,3,17,'09:00','14:00','00:00','13:00','18:48','00:00',3,1,11,2,0),(26,2015,3,18,'09:00','14:00','00:00','13:00','18:48','00:00',4,1,11,2,0),(27,2015,3,19,'09:00','14:00','00:00','13:00','18:48','00:00',5,1,11,2,0),(28,2015,3,20,'09:00','14:00','00:00','13:00','20:00','00:00',6,1,11,2,0),(29,2015,8,21,'08:00','13:00','00:00','12:00','17:30','00:00',6,1,19,4,0),(30,2015,8,22,'FG','FG','FG','FG','FG','FG',7,5,19,4,0),(31,2015,8,23,'FG','FG','FG','FG','FG','FG',1,5,19,4,0),(32,2015,8,24,'08:00','13:00','00:00','12:00','17:30','00:00',2,1,19,4,0),(33,2015,8,25,'08:00','13:00','00:00','12:00','17:30','00:00',3,1,19,4,0),(34,2015,8,26,'08:00','13:00','00:00','12:00','17:30','00:00',4,1,19,4,0),(35,2015,8,27,'08:00','13:00','00:00','12:00','17:30','00:00',5,1,19,4,0),(36,2015,8,28,'08:00','13:00','00:00','12:00','17:30','00:00',6,1,19,4,0),(37,2015,8,29,'FG','FG','FG','FG','FG','FG',7,5,19,4,0),(38,2015,8,30,'FG','FG','FG','FG','FG','FG',1,5,19,4,0),(39,2015,8,31,'08:00','13:00','00:00','12:00','17:30','00:00',2,1,19,4,0),(40,2015,9,1,'08:00','13:00','00:00','12:00','17:30','00:00',3,1,19,4,0),(41,2015,9,2,'08:00','13:00','00:00','12:00','17:30','00:00',4,1,19,4,0),(42,2015,9,3,'08:00','13:00','00:00','12:00','17:30','00:00',5,1,19,4,0),(43,2015,9,4,'08:00','13:00','00:00','12:00','17:30','00:00',6,1,19,4,0),(44,2015,9,5,'FG','FG','FG','FG','FG','FG',7,5,19,4,0),(45,2015,9,6,'FG','FG','FG','FG','FG','FG',1,5,19,4,0),(46,2015,9,7,'08:00','13:00','00:00','12:00','17:30','00:00',2,1,19,4,0),(47,2015,9,8,'08:00','13:00','00:00','12:00','17:30','00:00',3,1,19,4,0),(48,2015,9,9,'08:00','13:00','00:00','12:00','17:30','00:00',4,1,19,4,0),(49,2015,9,10,'08:00','13:00','00:00','12:00','17:30','00:00',5,1,19,4,0),(50,2015,9,11,'08:00','13:00','00:00','12:00','17:30','00:00',6,1,19,4,0),(51,2015,9,12,'FG','FG','FG','FG','FG','FG',7,5,19,4,0),(52,2015,9,13,'FG','FG','FG','FG','FG','FG',1,5,19,4,0),(53,2015,9,14,'08:00','13:00','00:00','12:00','17:30','00:00',2,1,19,4,0),(54,2015,9,15,'08:00','13:00','00:00','12:00','17:30','00:00',3,1,19,4,0),(55,2015,9,16,'08:00','13:00','00:00','12:00','17:30','00:00',4,1,19,4,0),(56,2015,9,17,'08:00','13:00','00:00','12:00','17:30','00:00',5,1,19,4,0),(57,2015,9,18,'08:00','13:00','00:00','12:00','17:30','00:00',6,1,19,4,0),(58,2015,9,19,'FG','FG','FG','FG','FG','FG',7,5,19,4,0),(59,2015,9,20,'FG','FG','FG','FG','FG','FG',1,5,19,4,0);
/*!40000 ALTER TABLE `cartao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colaborador`
--

DROP TABLE IF EXISTS `colaborador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colaborador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matr` int(11) DEFAULT NULL,
  `desligado` tinyint(1) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `feriasPrev` int(11) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `cel` varchar(16) DEFAULT NULL,
  `numCartao` int(11) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `Cargo_id` int(11) NOT NULL,
  `Setor_id` int(11) NOT NULL,
  `TipoJornada_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Cargo_id`,`Setor_id`,`TipoJornada_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colaborador`
--

LOCK TABLES `colaborador` WRITE;
/*!40000 ALTER TABLE `colaborador` DISABLE KEYS */;
INSERT INTO `colaborador` VALUES (1,1,0,'CARLOSALEXANDRE3107@GMAIL.COM',1,'(99) 9999-9999','(11) 11111-1111',1,'CARLOS ALEXANDRE DO NASCIMENTO ROSA',1,1,1),(2,2,0,'AAAAAAAAAA',1,'(99) 9999-9999','(99) 99999-9999',138,'PRISCILA REGO DA SILVA',2,2,2),(3,112238,0,'AAA',10,'(99) 9999-9999','(99) 99999-9999',125,'MILENA SANTOS COELHO',3,3,3),(4,112354,0,'AAAAAAAAAAA',12,'(22) 2222-2222','(22) 22222-2222',2,'ALERCI DE OLIVEIRA',4,4,1);
/*!40000 ALTER TABLE `colaborador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracao`
--

DROP TABLE IF EXISTS `configuracao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracao` (
  `id` int(11) NOT NULL,
  `preenCartao` tinyint(1) DEFAULT NULL,
  `inicioCartao` int(11) DEFAULT NULL,
  `anoExer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracao`
--

LOCK TABLES `configuracao` WRITE;
/*!40000 ALTER TABLE `configuracao` DISABLE KEYS */;
INSERT INTO `configuracao` VALUES (1,0,2,2010);
/*!40000 ALTER TABLE `configuracao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jornada`
--

DROP TABLE IF EXISTS `jornada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jornada` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ent1` varchar(5) DEFAULT NULL,
  `ent2` varchar(5) DEFAULT NULL,
  `ent3` varchar(5) DEFAULT NULL,
  `sai1` varchar(5) DEFAULT NULL,
  `sai2` varchar(5) DEFAULT NULL,
  `sai3` varchar(5) DEFAULT NULL,
  `diaSemana` int(1) DEFAULT NULL,
  `Ocorrencia_id` int(11) NOT NULL,
  `TipoJornada_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Ocorrencia_id`,`TipoJornada_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jornada`
--

LOCK TABLES `jornada` WRITE;
/*!40000 ALTER TABLE `jornada` DISABLE KEYS */;
INSERT INTO `jornada` VALUES (1,'FG','FG','FG','FG','FG','FG',7,5,1),(2,'08:00','13:00','00:00','12:00','17:30','00:00',3,1,1),(3,'08:00','13:00','00:00','12:00','17:30','00:00',4,1,1),(4,'08:00','13:00','00:00','12:00','17:30','00:00',5,1,1),(5,'08:00','13:00','00:00','12:00','17:30','00:00',6,1,1),(6,'08:00','13:00','00:00','12:00','17:30','00:00',2,1,1),(7,'FG','FG','FG','FG','FG','FG',1,5,1),(8,'00:00','00:00','00:00','00:00','00:00','00:00',1,1,0),(9,'09:00','14:00','00:00','13:00','18:48','00:00',2,1,0),(10,'09:00','14:00','00:00','13:00','18:48','00:00',3,1,0),(11,'09:00','14:00','00:00','13:00','18:48','00:00',4,1,0),(12,'09:00','14:00','00:00','13:00','18:48','00:00',5,1,0),(13,'09:00','14:00','00:00','13:00','18:48','00:00',6,1,0),(14,'09:00','14:00','00:00','13:00','18:48','00:00',7,1,0),(15,'FG','FG','FG','FG','FG','FG',1,5,2),(16,'07:00','10:40','00:00','10:10','13:30','00:00',2,1,2),(17,'07:00','10:40','00:00','10:10','13:30','00:00',3,1,2),(18,'07:00','10:40','00:00','10:10','13:30','00:00',4,1,2),(19,'07:00','10:40','00:00','10:10','13:30','00:00',5,1,2),(20,'07:00','10:40','00:00','10:10','13:30','00:00',6,1,2),(21,'07:00','','00:00','','11:00','00:00',7,1,2),(22,'FG','FG','FG','FG','FG','FG',1,5,3),(23,'08:00','13:00','00:00','12:00','17:30','00:00',2,1,3),(24,'08:00','13:00','00:00','12:00','17:30','00:00',3,1,3),(25,'08:00','13:00','00:00','12:00','17:30','00:00',4,1,3),(26,'08:00','13:00','00:00','12:00','17:30','00:00',5,1,3),(27,'08:00','13:00','00:00','12:00','17:30','00:00',6,1,3),(28,'FG','FG','FG','FG','FG','FG',7,5,3),(29,'FO','FO','FO','FO','FO','FO',1,5,4),(30,'07:00','13:00','','12:00','16:00','',2,1,4),(31,'07:00','13:00','','12:00','16:00','',3,1,4),(32,'07:00','13:00','','12:00','16:00','',4,1,4),(33,'07:00','13:00','','12:00','16:00','',5,1,4),(34,'07:00','13:00','','12:00','16:00','',6,1,4),(35,'07:00','','','','11:00','',7,1,4),(36,'FO','FO','FO','FO','FO','FO',1,5,5),(37,'06:00','13:00','','12:00','15:00','',2,1,5),(38,'06:00','13:00','','12:00','15:00','',3,1,5),(39,'06:00','13:00','','12:00','15:00','',4,1,5),(40,'06:00','13:00','','12:00','15:00','',5,1,5),(41,'06:00','13:00','','12:00','15:00','',6,1,5),(42,'06:00','00:00','','00:00','10:00','',7,1,5);
/*!40000 ALTER TABLE `jornada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `justificativa`
--

DROP TABLE IF EXISTS `justificativa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `justificativa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(100) DEFAULT NULL,
  `anexo` varchar(100) DEFAULT NULL,
  `Cartao_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Cartao_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `justificativa`
--

LOCK TABLES `justificativa` WRITE;
/*!40000 ALTER TABLE `justificativa` DISABLE KEYS */;
/*!40000 ALTER TABLE `justificativa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ocorrencia`
--

DROP TABLE IF EXISTS `ocorrencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ocorrencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desativado` tinyint(1) DEFAULT NULL,
  `sigla` varchar(45) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `tipoOcorrencia` int(1) DEFAULT NULL COMMENT 'TIPOOCORRENCIA - 0 = TODOS /  1 = JORNADA / 2 = CARTAO / 3 = CALENDARIO',
  `texto` tinyint(1) DEFAULT NULL,
  `anexo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ocorrencia`
--

LOCK TABLES `ocorrencia` WRITE;
/*!40000 ALTER TABLE `ocorrencia` DISABLE KEYS */;
INSERT INTO `ocorrencia` VALUES (1,0,'NR','NORMAL',0,0,0),(3,0,'FA','FALTA ',0,1,1),(4,0,'AT','ATESTADO MÉDICO',0,1,1),(5,0,'FO','FOLGA',0,1,0),(6,0,'ABF','ABONADA FALTA',0,1,0),(7,0,'ABA','ABONADO ATRASO',0,1,0),(8,0,'DECLA','DECLARAÇÃO DE COMPARECIMENTO',0,1,1),(9,0,'FE','FÉRIAS',0,1,0),(10,0,'SA','SAÍDA ANTECIADA',0,1,0),(11,0,'ACM','ATESTADO CENTRO MÉDICO',0,1,1),(12,0,'MH','MUDANÇA DE HORÁRIO',0,1,0),(13,0,'N','NÃO MARCOU ',0,1,0),(14,0,'RE','RECESSO',0,1,0);
/*!40000 ALTER TABLE `ocorrencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setor`
--

DROP TABLE IF EXISTS `setor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) DEFAULT NULL,
  `responsavel` varchar(100) DEFAULT NULL,
  `ramal` int(11) DEFAULT NULL,
  `sigla` varchar(45) DEFAULT NULL,
  `cancelado` tinyint(1) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setor`
--

LOCK TABLES `setor` WRITE;
/*!40000 ALTER TABLE `setor` DISABLE KEYS */;
INSERT INTO `setor` VALUES (1,'SETOR DE TECNOLOGIA DA INFORMACÃO','FABRÍCIO',8466,'STI',0,'SUPORTE@FEUC.BR'),(2,'CRECHE','',0,'CRECHE',0,''),(3,'RECURSOS HUMANOS','',0,'RH',0,''),(4,'MANUTENÇÃO','FRANCISCO/LUIZA',0,'MANUT.',0,''),(5,'','',0,'ADM.',0,''),(6,'','',0,'INSP.',0,''),(7,'','',0,'COORD. CAEL',0,''),(8,'','',0,'CENTRO MÉD.',0,''),(9,'','',0,'COORD. FIC',0,''),(10,'','',0,'CULTURAL',0,''),(11,'','',0,'TES.',0,''),(12,'','',0,'COM. SOC.',0,''),(13,'','',0,'SECR. CAEL',0,''),(14,'','',0,'SUPERI.',0,''),(15,'','',0,'PATR. E SEG.',0,''),(16,'','',0,'ATEND.',0,''),(17,'','',0,'REPROG.',0,''),(18,'','',0,'PORTAR.',0,''),(19,'','',0,'CRECHE',0,''),(20,'','',0,'BIBLIOT.',0,''),(21,'','',0,'CEPOPE',0,''),(22,'','',0,'SECRT. FIC',0,''),(23,'','',0,'ALMOX.',0,''),(24,'','',0,'SEF',0,''),(25,'','',0,'UNATIL',0,''),(26,'','',0,'RECREA.',0,'');
/*!40000 ALTER TABLE `setor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipocartao`
--

DROP TABLE IF EXISTS `tipocartao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipocartao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mes` int(2) DEFAULT NULL,
  `lancado` tinyint(1) DEFAULT NULL,
  `cancelado` tinyint(1) DEFAULT NULL,
  `ano` int(4) DEFAULT NULL,
  `colaborador_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`colaborador_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipocartao`
--

LOCK TABLES `tipocartao` WRITE;
/*!40000 ALTER TABLE `tipocartao` DISABLE KEYS */;
INSERT INTO `tipocartao` VALUES (10,1,0,0,2014,1),(11,3,1,1,2015,2),(12,3,0,0,2015,3),(13,1,0,0,2015,2),(14,3,0,0,2015,2),(15,4,0,0,2015,2),(16,9,0,0,2015,1),(17,9,0,0,2015,2),(18,9,0,0,2015,3),(19,9,1,0,2015,4),(20,12,0,0,2015,1),(21,12,0,0,2015,2),(22,12,0,0,2015,3),(23,12,0,0,2015,4),(24,8,0,0,2015,1),(25,8,0,0,2015,2),(26,8,0,0,2015,3),(27,8,0,1,2015,4),(28,8,0,0,2015,4),(29,1,0,0,2010,1);
/*!40000 ALTER TABLE `tipocartao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipojornada`
--

DROP TABLE IF EXISTS `tipojornada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipojornada` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) DEFAULT NULL,
  `desativado` tinyint(1) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipojornada`
--

LOCK TABLES `tipojornada` WRITE;
/*!40000 ALTER TABLE `tipojornada` DISABLE KEYS */;
INSERT INTO `tipojornada` VALUES (1,1,0,'08:00-17:30'),(2,2,0,'07:00-13:30/10:10-10:40'),(3,3,0,'08:00-17:30/12:00-13:00'),(4,4,0,'07:00-16:00/12:00-13:00'),(5,5,0,'06:00-15:00/12:00-13:00');
/*!40000 ALTER TABLE `tipojornada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desativado` tinyint(1) DEFAULT NULL,
  `perfil` tinyint(1) DEFAULT '1' COMMENT 'PERFIL - 0 = ADMINISTRADOR / 1 = OPERADOR',
  `senha` varchar(100) DEFAULT NULL,
  `Colaborador_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Colaborador_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,0,0,'827ccb0eea8a706c4c34a16891f84e7b',1);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-30 11:15:40
