<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<?php
	require "Style.php";
?>
<body>
	</br>
	<div id="bodyRodape">
		</br>
		</br>
		<center><img src="Imagens/rodape.png"/><center>
	</div>
</body>
</html>